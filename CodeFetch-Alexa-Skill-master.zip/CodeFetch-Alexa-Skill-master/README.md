# CodeFetch-Alexa-Skill
This Alexa Skill uses web scraping to curate StackOverflow Answers about code and algorithms, pastes it to PasteBin and inserts text into a code editor Atom.
<br>
### Invocation 
"Alexa, ask CodeFetch to fetch 'Binomial Theorem' in 'C++' "
<br>
You can play like this for any algorithm and language. As long as StackOverflow has it, we have it.

